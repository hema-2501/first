<div class="parent">
	<div>
		<img src="1.jpg.jpeg" width="" height="" class="pt-3 ps-4 ">
	</div>
	<div>
		<ul class="top pt-4">
			<li style="padding-right: 40px;"><a href="index.php">Home</a></li>
			<li style="padding-right: 40px;"><a href="about.php">About Us</a></li>
			<li style="padding-right: 40px;"><a href="ourservices.php">Our Services</a></li>
			<li style="padding-right: 40px;"><a href="gallery.php">Gallery</a></li>
			<li style="padding-right: 40px;"><a href="testimonials.php">Testimonials</a></li>
			<li style="padding-right: 60px;"><a href="contact.php">Contact Us</a></li>
		</ul>
	</div>
</div>