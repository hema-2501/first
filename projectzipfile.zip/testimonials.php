<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Cube Men Construction company</title>
	<link rel="icon" type="img/png" href="logo1.jpg">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

	<style>


		a{
   text-decoration: none;
   color: black;
}
.top{
	list-style-type: none ;
	display: flex; gap: 100px; padding: 0;
   
}

.top a{
   text-decoration: none;
   color: black;
}

a:hover{
	color: orange;
}
.parent{
	display: flex;
	justify-content: space-between; 
}
.posit {
    position: relative;
    top: -78px;
    z-index: -20;
}







		.tgg{
   font-size:"50px" !important;
   color: #ffd700;
   margin-right: 2px; 
   gap: 5px;
   margin-bottom: 35px;
}
.opp{
   font-size: 20px;
   color: black;
   text-align: justify;
   line-height: 1.7em;
   font-weight: 400;
   margin-bottom: 45px;

}
.ee{
   align-content: center;

}
.yow{
	border: 1px solid grey;
	border-radius: 20px;
	padding-top: 10px;
	padding-bottom: 10px;

}
.three{
	margin-top: 20px;
	margin-bottom:20px;
}
.were{
	color: grey;
}







	</style>


</head>
<body> 


	<?php include"header.php"?>

<div class="oviya posit">
	<h1 class="text-center ayisha">Testimonials</h1>
</div>
	<center><h1><b>What people are saying about us</b></h1></center>
	<div class="container">
		<div class="row three">
			<div class=" col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">We hired Bright Interiors to redesign our living room, and they delivered a beautiful, well-thought-out space. The team was efficient and really understood our vision.</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Venkatesan</h5></div>
			</div>
		</div>
		<div class=" col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">I am very happy with the work they did in my home. The design was both creative and practical, and the team was very responsive.</h6><br><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Balasubramani</h5></div>
			</div>
		</div>
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">From start to finish, their team exceeded my expectations. They listened to my ideas and transformed them into a beautiful, functional space.</h6><br><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Arumugam</h5></div>
			</div>
		</div>
		</div>
		<div class="row three">
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">They gave my office a fresh, modern look. Their design solutions were exactly what I needed, and the project was completed on time. Highly recommend!.</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Ganesh Pandi</h5></div>
			</div>
		</div>
		
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">Bright Interiors transformed my office space perfectly. Their team was professional and attentive. The design is stylish, functional, and really reflects our brand's identity.</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Nithish</h5></div>
			</div>
		</div>
		
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">Working with Bright Interiors was a fantastic experience. Their team understood my requirements and created a space that is both stylish and practical. Very satisfied!</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Jeevanantham</h5></div>
			</div>
		</div>
		</div>
		<div class="row three">
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">They did an amazing job on our office interior. They created a space that is both functional and inviting. We couldn’t be happier with the results.</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Manikandan</h5></div>
			</div>
		</div>
		
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">I couldn’t be more pleased with the results from them. They transformed my home into a stylish, welcoming space. The team was professional and creative.</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Mariyyapan</h5></div>
			</div>
		</div>
		
		<div class="col-9 col-sm-12 col-md-6 col-lg-4 yow">
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">They took my ideas and turned them into reality. The work is top-notch, and I love the final design. The team was always helpful and friendly.</h6><hr class="were">
        			<div class="d-flex">
        				<div>
        					<img src="test.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Nandha kumar</h5></div>
			</div>
		</div>
		</div>
    </div>

    <?php include"footer.php"?>
</body>
</html>