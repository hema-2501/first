<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cube Men Construction company</title>
	<link rel="icon" type="img/png" href="logo1.jpg">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

	<style>



    a{
   text-decoration: none;
   color: black;
}
.top{
  list-style-type: none ;
  display: flex; gap: 100px; padding: 0;
   
}

.top a{
   text-decoration: none;
   color: black;
}

a:hover{
  color: orange;
}
.parent{
  display: flex;
  justify-content: space-between; 
}
.posit{
    position: relative;
    top: -87px;
    z-index: -20;
}










.get{
    margin-top: 40px;
    margin-bottom: 20px;
}
.vai{
    margin-bottom: 20px;
    margin-top: 50px;
}
.chu::after{
    content: "\f178";
    font-family: "fontawesome";
    padding-left: 10px;
    padding-right: -10px;

}
.yow{
    margin-top: 10px;
}
.uk{
    display: flex;
}
.pipe{
    display: flex;
    list-style-type: none;
    gap: 50px; padding: 0;
    margin-left: 25%;
    font-size: 20px;
    padding-bottom: 40px;
}

.padd-30 {
    padding-left: 30px !important;
}
.cat{
    color: white;
    list-style-type: none;
    gap: 70px;
    padding-left:20%;
    margin-bottom:20px ;

}
.cat a{
    text-decoration: none;
    color: white;
}
/*.sub{
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--dark-divider-color);
    border-radius: 50%;
    width: 40px;
    height: 40px;
    margin-right: 10px;
}*/


.sir{
    gap: 7px;
}
.hello{
    color: white;
    border: 1px solid white;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    align-items: center;
    justify-content: center;

}
.fast a{
    text-decoration: none;

}


/*HARISH*/

.main-heading{
    text-align: center;
    font-weight: bold;
    font-size: 34px;
}












		



.Vertical{
   border-right: 2px solid black;
   height:250px ;
   margin:-1px ;

}


.icon-circle {
  width: 60px;
  height: 60px;
  background-color: #f7931e;
  color: white;
  font-size: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
}


.faq-section {
  max-width: 800px;
  margin: auto;
  padding: 20px;
  font-family: Arial, sans-serif;
}

.faq-question {
  cursor: pointer;
  font-weight: bold;
  margin: 10px 0;
  position: relative;
  padding-right: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.faq-icon {
  font-size: 20px;
  transition: transform 0.3s ease;
}

.faq-answer {
  display: none;
  padding: 10px 0 20px 0;
  font-weight: normal;
  color:#555;
}

.OG {

  color: black;
}
.top{
  list-style-type: none ;
  display: flex; gap: 85px; padding: 0;
  text-decoration: none;
}
  a{
   text-decoration: none;
   color: black;
 }
   
    .faq-icon::before{
   display: flex;
   }

.thfy{

  background-color:white !important;
  padding: 36px 60px;
}


.top::before{
 
  font-family: "Font Awesome 5 Free";
  content: "\f101"; 
  font-weight: 900;


}


.deg{
 color:white;
 padding-top:20px;
}

.deg1{
  color:white;
}
	</style>

</head>
<body>

	<?php include"header.php"?>

<div class="oviya posit">
	<h1 class="text-center ayisha">About Us </h1>
</div>


	<div class="container">
		<div class="row">
			<div class="col-12 col-lg-6">
				
				<img src="images/gallery1.png"  width="100%">
			</div>
		<div class="col-12 col-lg-6">
		   	<h3>Best Structure Buildings in Kodaikanal</h3>
		   	<h2>Bright Interiors</h2>
		   	<p>We are a team of qualified professionals committed to delivering high-quality work on time. Since inception, we’ve focused on maintaining excellent standards and client satisfaction. Equipped technically and financially, we handle projects of any scale with confidence, ensuring top-notch quality in every project we complete.</p>
		   	<p>As turnkey contractors, we specialize in interior designing for commercial spaces and offices. We are registered for sales and commercial tax in Kerala and Tamil Nadu and are also ESI registered.</p>
		   	<a href="home-interior-designers-in-coimbatore.php" class="btn btn-warning rounded-pill" style="background-color:#f7931e; text-decoration:none;">Contact Now<i class="bi bi-arrow-right ms-2"></i></a>
		   </div>

		</div>

	</div><br>


<div style="background-color:gray;  padding-bottom: 45px;">
	<div class="container text-center">
		<h6 class="text-uppercase deg" id="OG"><b>Our Goals</b></h6>
		<h1 class="fw-bold mb-5 deg1">Top Interior Designers in kodaikanal</h1>
		<div class="container thfy">
		<div class="row">
			<div class="col-12 col-sm-6 col-lg-4 Vertical">
                <div class="icon-circle mb-3 mx-auto">
                	

                	  <i class="bi bi-eye-fill"></i>

                </div>
                

				
					<h3>vision</h3>
					<p>To be a leader in interior design industry, recognized for delivering innovative, functional, and aesthetically pleasing spaces that exceed client expectations while contributing to the growth and development of the communities we serve.</p>


			</div>
			<div class="col-12 col-sm-6 col-lg-4 Vertical">

				<div class="icon-circle mb-3 mx-auto">
					 <i class="bi bi-bullseye"></i>

				</div>


				
					<h3>Mission</h3>
					<p>To  provide exceptional interior design services, ensuring high-quality craftsmanship, timely delivery, and cost-effective solutions. We aim to create inspiring, personalized spaces that reflect our client's vision and enhance their lifestyles and business environments.</p>


				
			</div>

			<div class="col-12 col-sm-6 col-lg-4 " >

				<div class="icon-circle mb-3 mx-auto">
					 <i class="bi bi-cash-coin"></i>
				</div>
				
					<h3>Our Values</h3>
					<p>We value creativity, integrity, and customer satisfaction. Our commitment to quality, transparency, and continuous improvement ensures that every project is completed to the highest standards. We believe in fostering lasting relationships with clients through trust and excellence.</p>

				
			</div>
			


			</div>
		</div>
			<div>

				


			</div>






			

		</div></div>
	</section>
	<br>
		<div class="container">
			<div class="row">
			<h1 class="fw-bold mb-3 text-center">Top interior Designers</h1>
		   <div class="col-12 col-lg-6">
			
			<h1>Faq</h1>
	<div class="faq-item">
			<div class="faq-question" onclick="toggleFaq(this)">

			<h5>1.What types of spaces do you specialize in designing?</h5>
			<span class="faq-icon">+</span>
		    </div>

		    <div class="faq-answer">
             We specialize in designing interiors for homes, offices, commercial spaces, and more, ensuring each project reflects the client’s unique vision and needs.
           </div><hr>
       </div>
  


  <div class="faq-item">
    <div class="faq-question" onclick="toggleFaq(this)">
      <h5>2. How long does it take to complete a project?</h5>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-answer">
      The timeline for each project varies based on size and complexity. However, we prioritize timely delivery, ensuring your space is completed within the agreed-upon timeframe.
    </div><hr>
  </div>

<div class="faq-item">
    <div class="faq-question" onclick="toggleFaq(this)">
     <h5> 3. What is the cost of your interior design services?</h5>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-answer">
      Costs depend on the scope of work and materials chosen. We provide personalized quotes based on your requirements and budget to ensure a cost-effective solution.
    </div><hr>
</div>
</div>

				<div class="col-12 col-lg-6">
					<img src="building1.jpg"  width="600" height="400">
				</div>
			
		</div>
	</div><br>

  <?php include"footer.php"?>

<script>
    const questions = document.querySelectorAll('.faq-question');

questions.forEach(q => {
  q.addEventListener('click', () => {
    const answer = q.nextElementSibling;
    answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
    
    // Change "+" to "-" when open
    const icon = q.querySelector('span');
    icon.textContent = icon.textContent === '+' ? '-' : '+';
  });
});
</script>










 

</body>
</html>