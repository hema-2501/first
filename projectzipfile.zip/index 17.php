<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Best sturcture Buildings in coimbatore|palakkad|kerala</title>
	<link rel="icon" type="img/png" href="logo.jpg">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>
	 <div class="diagram" >
		<div>
			
			<img src="logo.jpg">
		</div>
		<div>
			<ul class="unorder">

				<li><a href="https://brightinteriors.in/">home</a></li>
				<li><a href="https://brightinteriors.in/top-interior-designers-in-kerala.php">About</a></li>
				<li class="xx">Services</li>
				<li><a href="https://brightinteriors.in/best-construction-company-in-coimbatore.php">Gallery</a></li>
				<li><a href="https://brightinteriors.in/blog.php">Blog</a></li>
				<li><a href="https://brightinteriors.in/interior-designers-in-coimbatore.php">Testimonials</a></li>
				<li><a href="https://brightinteriors.in/home-interior-designers-in-coimbatore.php">Contact</a></li>
			</ul>
	</div>
</div>




	<div>
		<img src="image1.jpg" width="100%">
	</div>




	<div class="homee">
		<div class="nature">
			<img src="home.jpg" height="345px" width="440px">
			<img src="image2.png" class="world" height="292.59" width="385px">		
		</div>
		<div class="yy">
			<h3 class="spb"> BEST SRTUCTURE BUILDINGS IN PALAKKAD</h3>
			<h5 class="arthi"> Bright interiors</h5>
			<h6 class="pavi"> We specialize in creating inspiring and functional spaces that reflect your unique style. Whether transforming a single room or an entire property, we focus on quality craftsmanship and attention to detail.</h6>
			<h6 class="jaya">Our team works closely with clients, ensuring every design is tailored to their needs. With innovative solutions and personalized service, we bring your vision to life, making every space beautiful and functional.</h6>
		<div class="house">
			<h3>Budget Friendly</h3>
			<h3>On Time Delivery</h3>
		</div>
		<a href="https://brightinteriors.in/top-interior-designers-in-kerala.php" class="cycle "> about us</a>

		</div>
		
	</div>
  



<div class="container  jag">
	<div class="row">
		<div class="col-12 col-md-6 col-lg-3 text-center vertical-line" >
		<img src="roof.png">
			<h1>10+</h1>
			<h4>years of experience</h4>
		</div>
		<div class="col-12 col-md-6 col-lg-3 text-center vertical-line">
		<img src="roof.png">
		<h1>500+</h1>
	    <h4>completed projects</h4>
		</div>
		<div class="col-12 col-md-6 col-lg-3 text-center vertical-line">
		<img src="roof.png">
		<h1>20+</h1>
			<h4>ongoing project</h4>
			
		</div>
		
		 <div class="col-12 col-md-6 col-lg-3 text-center vertical-line">
			<img src="roof.png">
		<h1>520+</h1>
			<h4>happy clients</h4>
			
		</div>
	</div>

</div>
<center><div>
	<h6 style="color:#d15901;">Our Services</h6>
	<h1>Best Structure Buildings in Coimbatore</h1>
</div></center>


<div class="container theee">
	<div class="row g-3">

		<div class="col-12 col-md-6 col-lg-4">
			<img src="buildingg.jpg">
		</div>
		<div class="col-12 col-md-6 col-lg-4">
			<img src="building1.jpg">
		</div>
		<div  class="col-12 col-md-6 col-lg-4">
			<img src="building2.jpg">
		</div>
		<div  class="col-12 col-md-6 col-lg-4">
			<img src="building3.jpg">
		</div>
		<div  class="col-12 col-md-6 col-lg-4">
			<img src="building5.jpg">
		</div>
		<div class="col-12 col-md-6 col-lg-4">
			<img src="building6.jpg">
		</div>

</div>
</div>
  <div class="container boy">
  	<div class="row">
  	<div class="col-12 col-md-6 col-lg-6">
  		<h5> Best Structure Buildings in Kerala</h5>
  		<h2 style="color:#d15901;">How We Work</h2>
  		<p>At Bright Interiors, we follow a streamlined process to ensure your vision is brought to life with precision, creativity, and care.</p>
      <div class="d-flex">
      	<div class="me-3">
      		<i class="fa fa-phone barath"></i>
      	</div>
      	<div>
      		<h5>Consultation</h5>
  		<p>We understand your needs and preferences to create a personalized plan.</p><hr>
      	</div>
      </div>
  		
  		<h5>Design & Planning</h5>
  		<p>Our team designs and plans the space with detailed attention to functionality.</p><hr>
  		<h5>Execution & Delivery</h5>
  		<p>We execute with professionalism, delivering your project on time and within budget.</p></hr>
  		  	</div>


<div class="col-12 col-md-6 col-lg-6">
	<img src="interior.jpg" width="100%">
</div>
</div>
</div>
 
</body>
</html>






 