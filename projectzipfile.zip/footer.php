<div class="container-fluid">
			<div class="row get">
		<iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d7831.880091823186!2d76.954042!3d11.043122!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMTHCsDAyJzQwLjMiTiA3NsKwNTYnNDIuMiJF!5e0!3m2!1sen!2sin!4v1753280229814!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
	</div>
	<div style="background-color: black; height:400px; width: 100%;" class="mt-5">
		<div>
			<center><img src="1.jpg.jpeg" class="yow"><br><hr style="color:white; padding-left: 30px;">
				<p style="color:white; font-size: 23px;" class="ps-5 pe-5">Bright Interiors is a team of energetic, qualified professionals committed to delivering high-quality workmanship within the scheduled timeframe. Since its inception, the company has focused on maintaining excellent work standards and meeting client satisfaction.</p>

		</div>
		<div>
			<ul style="color:white;" class="pipe">
				<li><i class="fa fa-angle-double-right"></i><a href="index.php">Home</a></li>
				<li><i class="fa fa-angle-double-right"></i><a href="about.php"> About Us</a></li>
				<li><i class="fa fa-angle-double-right"></i><a href="ourservices.php">Our Services</a></li>
				<li><i class="fa fa-angle-double-right"></i><a href="gallery.php">Gallery</a></li>
				<li><i class="fa fa-angle-double-right"></i><a href="testimonials.php">Testimonals</a></li>
				<li><i class="fa fa-angle-double-right"></i><a href="contact.php">Contact Us</a></li>
			</ul>
		</div>
		<div class="container">
			<div class="row fast">
			<div class="col-lg-2 text-center g-2" style="color:white;">
				<i class="fa fa-phone"></i>
				<a href="tel:+919342728028">9361996165</a>
			</div>
			<div class="col-lg-3 text-center g-2" style="color:white;">
				<i class="fa fa-envelope"></i>
				<a href="mailto=ka874790@gmail.com">hemabala2501@gmail.com</a>
			</div>
			<div class="col-lg-7 text-center d-flex g-2" style="color:white;">
				<i class="fa fa-map-marker"></i>
				<h6>02/757 Palani Bypass,Palani Road,Dindigul-624001</h6>
			</div>
		</div>
		</div>
		

			
		
	</div>

	
</div>
</div>

