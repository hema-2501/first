<?php



$host="localhost";
$username="root";
$password="";
$database="user_details";

// create connection
$conn=new mysqli($host,$username,$password,$database);


// 
if(!$conn){
	die("connection failed:".mysqli_connect_error());
}





?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Cube Men Construction company</title>
	<link rel="icon" type="img/png" href="logo1.jpg">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


  <style>
  	
  	.top {
  		list-style-type: none;
  		display: flex;
  	}
  	.top a {
  		text-decoration: none;
  		color: black;
  	}
  	.top li {
  		padding-right: 100px;
  	}
  	.parent {
  		display: flex;
  		justify-content: space-between;
  	}









  	.posit{
  		position: relative;
  		top: -72px;
  		z-index: -20;
  	}
  	.martop-35{
  		margin-top: -35px;
  	}



    
    a{
   text-decoration: none;
   color: black;
}
.top{
  list-style-type: none ;
  display: flex; gap: 100px; padding: 0;
   
}

.top a{
   text-decoration: none;
   color: black;
}

a:hover{
  color: orange;
}
.parent{
  display: flex;
  justify-content: space-between; 
}
.posit {
    position: relative;
    top: -78px;
    z-index: -20;
}

















  </style>
</head>
<body>

<!-- 	<div class="diagram" >
		<div>
			
			<img src="logo.jpg">
		</div>
		<div>
			<ul class="unorder">

				<li><a href="https://brightinteriors.in/">home</a></li>
				<li><a href="https://brightinteriors.in/top-interior-designers-in-kerala.php">About</a></li>
				<li class="xx">Services</li>
				<li><a href="https://brightinteriors.in/best-construction-company-in-coimbatore.php">Gallery</a></li>
				<li><a href="https://brightinteriors.in/blog.php">Blog</a></li>
				<li><a href="https://brightinteriors.in/interior-designers-in-coimbatore.php">Testimonials</a></li>
				<li><a href="https://brightinteriors.in/home-interior-designers-in-coimbatore.php">Contact</a></li>
			</ul>
	</div>
</div> -->

<?php include"header.php"?>

<div class="oviya posit">
	<h1 class="text-center ayisha">Contact Us</h1>
</div>

<div class="container martop-35">
	<h1 class="main-heading">Home Interior Designers in Dindigul</h1>
	<div class="row">
		<div class="col-lg-5 bajaj">
			<div class="d-flex ps-5 sha pb-1">
				<div>
					<i class="fa fa-home dev"></i>
				</div>
				<div>
					<h6>Address1</h6>
					<p>No. 6/5,Rm colony, vinayaga Nagar north, puthupatti, dindigul, Tamil Nadu, India</p>
					
				</div>
				
			</div>
			<hr>
			<div class="d-flex ps-5 pb-1">
			<div>
				<i class="fa fa-home dev"></i>
			</div>
			<div>
				<h6>Address2</h6>
				<p>Aesthetic interiors shopno-4/936, big bazaar street, Peelamedu, Coimbatore, Tamilnadu</p>
			</div>
		</div><hr>

        <div class="d-flex ps-5 pb-1">
			<div>
				<i class="fa fa-phone dev"></i>
			</div>
			<div>
			<div>
				<h6>phone number</h6></div>
				<div class="shy">
				<a href="tel:+919342728028">+91 9361991567</a><br>
				<a href="tel:+916374830484">+91 6369147306</a>
			</div>
		</div>
	</div><hr>
		<div class="d-flex ps-5 pb-1">
			<div>
				<i class="fa fa-envelope dev"></i>
			</div>
			<div>
			<div>
				<h6>e-mail support</h6></div>
				<div class="shy">
				<a href="mailto:ka874790@gmail.com"> hemabala2501@gmail.com</a><br>
				
			</div>
		</div>
	</div>
		
			

	</div>
	<div class="col-lg-7">
			
			<div class="yyyyy">
				<h5 class="text-center mail">Send Mail</h5>
				<h1 class="text-center">We would love to hear from you</h1>
			</div>
			<div class="container">
			<div class="row">
				<div class="d-flex padd-30">
				
				<input type="text" name="username" placeholder="your name*" class="tank ms-0">
				<input type="email" placeholder="email address" class="water">
			</div>
		</div>
	</div>
	<div class="row">
				<div class="d-flex go ps-4">
				
				<input type="text" name="username" placeholder="phone number" class="tank">
				
				<input type="email" placeholder="Select Services" class="water">

			
			</div>
			
			<div class="vai">
				

			<textarea type="text" name="username" placeholder="enter your message" class="your"></textarea></div>
			<div class="text-center nope"><button class="chu">submit</button></div>
					
				
			</div>

		</div>
	</div>
			
			
		</div>



		<?php include"footer.php"?>


<!-- <script src="script.js">

</script> -->




</body>
</html>






 