// 
// var a=10;
// b=20;
// c=a+b;
// console.log(c)



// function hr() {
// 	// var head1 = document.getElementById('has');
//     //    head1.innerHTML=c 


//     var amazon=parseInt(document.getElementById('nive').value);


//     // console.log(amazon)

//     var ayush=parseInt(document.getElementById('oviya').value);
//     // console.log(ayush)
//      var abi=amazon+ayush
//      console.log(abi)
//      // var abi=document.getElementById()

//      var hry=document.getElementById("has");
//      hry.innerHTML=(abi)
     


// }
// function hr() {
//     // var head1 = document.getElementById('has');
//     //    head1.innerHTML=c 


//     var amazon=parseInt(document.getElementById('nive').value);


//     // console.log(amazon)

//     var ayush=parseInt(document.getElementById('oviya').value);
//     // console.log(ayush)
//      var abi=amazon+ayush;
//      console.log(abi);
//      // var abi=document.getElementById()

//      var hry=document.getElementById("has");
//      hry.innerHTML=(abi);
     


// }
// function ha() {
//     // var head1 = document.getElementById('has');
//     //    head1.innerHTML=c 


//     var amazon=parseInt(document.getElementById('nive').value);


//     // console.log(amazon)

//     var ayush=parseInt(document.getElementById('oviya').value);
//     // console.log(ayush)
//      var abi=amazon-ayush;
//      console.log(abi);
//      // var abi=document.getElementById()

//      var hry=document.getElementById("has");
//      hry.innerHTML=(abi);
     


// }
// function hb() {
//     // var head1 = document.getElementById('has');
//     //    head1.innerHTML=c 


//     var amazon=parseInt(document.getElementById('nive').value);


//     // console.log(amazon)

//     var ayush=parseInt(document.getElementById('oviya').value);
//     // console.log(ayush)
//      var abi=amazon*ayush;
//      console.log(abi);
//      // var abi=document.getElementById()

//      var hry=document.getElementById("has");
//      hry.innerHTML=(abi);
     


// }
       
// function hc() {
//     // var head1 = document.getElementById('has');
//     //    head1.innerHTML=c 


//     var amazon=parseInt(document.getElementById('nive').value);


//     // console.log(amazon)

//     var ayush=parseInt(document.getElementById('oviya').value);
//     // console.log(ayush)
//      var abi=amazon/ ayush;
//      console.log(abi);
//      // var abi=document.getElementById()

//      var hry=document.getElementById("has");
//      hry.innerHTML=(abi);
// }
// var john =document.createElement("h1");

// john.textContent="welcome";
// document.body.appendChild(john);

// console.log(john);

// var image=document.createElement("img");
// image.src="roof.png";
// document.body.appendChild(image);



// john.textcontent="welcome";

// document.body.appendchild(john);

// var image=document.createElement("img");
// image.src="image1.jpg";

// var sam = document.createElement("h2");
// sam.textContent="Best Construction Comany in Coimbatore";
// // document.body.appendchild(sam);

// var image1= document.createElement("img");
// image1.src="building1.jpg";
// image1.classList.add("col-lg-3");

// var image2=document.createElement("img");
// image2.src="building2.jpg";
// image2.classList.add("col-lg-3");

// var image3=document.createElement("img");
// image3.src="building3.jpg";
// image3.classList.add("col-lg-3");

// var image4=document.createElement("img");
// image4.src="building5.jpg";
// image4 .classList.add("col-lg-3");

// var coffee=document.getElementById("tea");


// document.body.appendChild(sam);

// coffee.appendChild(image1);
// coffee.appendChild(image2);
// coffee.appendChild(image3);
// coffee.appendChild(image4);

function him(){
    var head1 =document.getElementById("swe").value;
    // head1.innerHTML=
    console.log(head1)
    var head2 =parseInt(document.getElementById("sweet").value) ;
        console.log(head2)

var good=document.getElementById("swee");

        if ( head2 >= 18) {
    good.innerHTML=head1 + " Eligible";
} else {
    good.innerHTML="Not Eligible";
}



}
