<!DOCTYPE html> 
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cube Men Construction company</title>
	<link rel="icon" type="img/png" href="logo1.jpg">
	<link rel="stylesheet" type="text/css" href="style.css"> 
	<!-- <link rel="stylesheet" type="text/css" href="main.css"> -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
 
	<style>
		
		*{
	font-family: "Hanken Grotesk", sans-serif;
}

@import url('https://fonts.googleapis.com/css2?family=Hanken+Grotesk:ital,wght@0,100..900;1,100..900&display=swap');
a{
   text-decoration: none;
   color: black;
}
.top{
	list-style-type: none ;
	display: flex; gap: 100px; padding: 0;
   
}

.top a{
   text-decoration: none;
   color: black;
}

a:hover{
	color: orange;
}
.parent{
	display: flex;
	justify-content: space-between; 
}
.parent1{
	display: flex; column-gap: 10px;
   margin-bottom: 150px;
   margin-top: -13px;
}
h1{
	color: orange;
}
.parent3{
	display: flex; gap: 40px;
   margin-left: 28px;
   margin-bottom: 15px;
}
.parent4{
	/*position: relative;
    display: inline-block;
    background: linear-gradient(82deg, rgba(226, 101, 0, 1) 4%, rgba(255, 154, 30, 1) 49%, rgba(226, 101, 0, 1) 80%);
    color:white;
    font-size: 16px;
    font-weight: 700;
    line-height: 1em;
    text-transform: capitalize;
    border-radius: 25px;
    padding: 17px 46px 17px 20px;
    transition: all 0.5s ease-in-out;
    overflow: hidden;
    z-index: 0;
    border: none;*/
    margin-left: 30px;

}
.parent4 a{
   text-decoration: none !important;
}
.para{
	line-height: 1.7em;
    margin-bottom: 20px;
    text-align: justify;
    font-size: 17px;
    color: black;
    font-weight: 400;
}
.main{
	font-weight: 700;
    line-height: 1.1em;
    color: #d15901;
    font-size: 32px;
    margin-bottom: 0px;
}
.aaa{
	text-transform: uppercase !important;
    font-size: 14px !important;
    font-weight: bold !important;
    letter-spacing: 2px !important;
}
.image3{
   position: absolute;
   left: 277px;
   top: 200px;
}
.bold{
   position: relative;
}
.by::after{
   content: "\f107";
    font-family: "FontAwesome";
    font-weight: 900;
    font-size: 14px;
    margin-left: 8px;
}
.yy{
   margin-left:240px;
}
.parent4::after{
   content:"\f178" ;
   font-family: "fontAwesome";
}
.as{
   background: #ffa25d;
   border-radius:32px;
   border:2px solid #bcbfdb65;
   padding: 70px 40px;
   backdrop-filter: blur(10px);
    background: linear-gradient(82deg, rgba(226, 101, 0, 1) 4%, rgba(255, 154, 30, 1) 49%, rgba(226, 101, 0, 1) 80%);
    margin-top: -24px;
 }
.uu{
   text-transform: uppercase !important;
    font-size: 14px !important;
    font-weight: bold !important;
    letter-spacing: 2px !important;
}
.oi{
   font-weight: 700;
     line-height: 1.1em;
    color: #d15901;
    font-size: 32px;
    margin-bottom: 0px;
}
.ty{
   line-height: 1.7em;
    margin-bottom: 20px;
    text-align: justify;
    font-size: 17px;
    color: black;
    font-weight: 400;

}
.fiv{
   margin-top: 70px;
}
.vertical-line{
   border-right: 2px solid black;
   height: 150px;
   margin: -1px;
}
.we{
   color: #d15901;
   text-align: center;
   margin-top: 10px;
}
.po{
   margin-top: 2px;
   text-align: center;
}
.fi::before{
  font-family: "FontAwesome";
  font-weight: 900;
  content: "\f2b9";
}
.ui::before {
    content: "\f058";
    font-family:"FontAwesome";
    font-size: 20px;
    font-weight: 900;
    line-height: normal;
    color: #d15901;
    display: inline-block;
    top: 2px;
    left: 0;
}
.wa::before{
   content:"\f1b3";
   font-family: FontAwesome;
   font-size: 30px;
}
.np::before{
   content: "\f207";
   font-family: FontAwesome;
   font-size: 30px;
}





 .hero-section {
          background-image: url(../../bright-interior-image/web-images/arrow-white.svg);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    transform: translate(-20px, -50%);
    transition: all 0.4s ease-in-out;



      /*background: url("wow.jpg") no-repeat center center/cover;
      height: 100vh;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      position: relative;*/
    }
  .hero-overlay {
      background-image: url("images/images/bk.jpg");
      padding: 50px 20px;
      background-attachment: fixed;
      width: 100%;
    }

   /* .hero-selction {
      background-image: url();
    }*/

    .hero-text h1 {
      font-size: 2.5rem;
      font-weight: bold;
      text-align: center;
    }

   .hy {
    position: relative;
    display: inline-block;
    background: linear-gradient(82deg, rgba(226, 101, 0, 1) 4%, rgba(255, 154, 30, 1) 49%, rgba(226, 101, 0, 1) 80%);
    color:white;
    font-size: 16px;
    font-weight: 700;
    line-height: 1em;
    text-transform: capitalize;
    border-radius: 25px;
    padding: 17px 46px 17px 20px;
    transition: all 0.5s ease-in-out;
    overflow: hidden;
    z-index: 0;
    border: none;
    text-align: center;
    margin-top: 35px;
    }

    .hy::after{
   content:"\f178" ;
   font-family: "fontAwesome";
}

.hy a{
   text-decoration: none;
}
.mm{
   font-weight: 700;
    line-height: 1.1em;
    color: #d15901;
    font-size: 32px;
    margin-bottom: 0px;
}
.qq{
   line-height: 1.7em;
    margin-bottom: 20px;
    text-align: justify;
    font-size: 17px;
    color: black;
    font-weight: 400;
}
.ii{
   text-transform: uppercase;
   color: #d15901;
   letter-spacing: 2px;
   margin-bottom: 10px;
   margin-top: 10px;
}

.you{
   position: relative;
    display: inline-block;
    background: linear-gradient(82deg, rgba(226, 101, 0, 1) 4%, rgba(255, 154, 30, 1) 49%, rgba(226, 101, 0, 1) 80%);
    color:white;
    font-size: 16px;
    font-weight: 700;
    line-height: 1em;
    text-transform: capitalize;
    border-radius: 25px;
    padding: 17px 46px 17px 20px;
    transition: all 0.5s ease-in-out;
    overflow: hidden;
    z-index: 0;
    border: none;
    margin-bottom: 20px;
    margin-top: 20px;

}
.you::after{
   content:"\f178" ;
   font-family: "fontAwesome";
}
.sd{
   font-weight: 700;
    line-height: 1.1em;
    color: #d15901;
    font-size: 32px;
    margin-bottom: 0px
}
.tgg{
   font-size:"50px" !important;
   color: #ffd700;
   margin-right: 2px; 
   gap: 5px;
   margin-bottom: 35px;
}
.opp{
   font-size: 20px;
   color: black;
   text-align: justify;
   line-height: 1.7em;
   font-weight: 400;
   margin-bottom: 45px;

}
.ee{
   align-content: center;

}
.jk{
   font-weight: 700;
    line-height: 1.1em;
    color: #d15901;
    font-size: 32px;
    margin-bottom: 0px;
    margin-top: 20px;
}
.lo{
   color: #d15901;
}
.hoo{
   color: #17012C;
    font-family: var(--title-font);
    font-size: 22px;
    font-style: normal;
    font-weight: 700;
    line-height: 32px;
    overflow: hidden;
 }
 .tube{
    position: relative;
    padding: 24px;
    max-width: 400px;
    border-radius: 16px;
    border: 1px solid #E5E5E5;
    background-color: #fff;
    -webkit-border-radius: 16px;
 }
 .black{
   color: white;
}
.blue{
   margin-left: 40px;
}


	</style>
</head>
<body> 
	 <?php include"header.php"?>
<div>
		<img src="image1.jpg" width="100%" style="position: relative; top: -78px; z-index: -10;">
	</div>

   <div class="container">
      <div class="parent1">
      <div class="bold">
         <img src="super.jpg" height="345px" width="440px">
         <img src="gal4.jpg" class="image3" height="292.59px" width="385px">
      </div>
      <div class="yy">
         <h3 class="aaa">BEST STRUCTURE BUILDINGS IN KODAIKANAL</h3>
         <h5 class="main">Bright Interiors</h5>
         <h6><p class="para">We specialize in creating inspiring and functional spaces that reflect your unique style. Whether transforming a single room or an entire property, we focus on quality craftsmanship and attention to detail.</p>
         <p  class="para">Our team works closely with clients, ensuring every design is tailored to their needs. With innovative solutions and personalized service, we bring your vision to life, making every space beautiful and functional.</p></h6>
      
         <div class="parent3">
         <h5 class="ui">Budget Friendly</h5>
           <h5 class="ui">On Time Delivery</h5>
       </div>
       <a href="about.php" class="btn btn-warning rounded-pill parent4" style="background-color:#f7931e; text-decoration:none;">About Us<i class="bi bi-arrow-right ms-2 "></i></a>
</div></div>
   </div>





	<div class="container as">
		<div class="row">
			<div class="col-3 text-center vertical-line">
			     <img src="images/images/home3.png">
			     <h6>10+</h6>
                 <span>Years of Experience</span>
			</div>
			<div class="col-3 text-center vertical-line">
				<img src="images/images/home3.png">
				<h6>500+</h6>
				<span>Completed Projects</span>
			</div>
			<div class="col-3 text-center vertical-line">
				<img src="images/images/home3.png">
				<h6>20+</h6>
				<span>Ongoing Projects</span>
			</div>
			<div class="col-3 text-center">
				<img src="images/images/home3.png">
				<h6>520+</h6>
				<span>Happy Clients</span>
            </div>
			
		</div>
	</div>
    <h6 class="we">Our Services</h6> 
   <h1 class="po">Best Structure Buildings in Dindigul</h1>
	<div class="container">
		<div class="row g-4">
			<div class="col-4 col-sm-12 col-md-6 col-lg-4">
				<img src="serlast2.jpg" width="100%">
			</div>
			<div class="col-4 col-sm-12 col-md-6 col-lg-4">
				<img src="images/images/r7.jpg" width="100%">
			</div>
			<div class="col-4 col-sm-12 col-md-6 col-lg-4">
				<img src="building1.jpg" width="100%">
			</div>
			<div class="col-4 col-sm-12 col-md-6 col-lg-4">
				<img src="images/images/r4.jpg" width="100%">
			</div>
			<div class="col-4 col-sm-12 col-md-6 col-lg-4">
				
              <img src="images/images/r5.jpg" width="100%">
			</div>
			<div class="col-4 col-sm-12 col-md-6 col-lg-4">
				<img src="images/images/r6.jpg" width="100%">
			</div>
		</div>
	</div>


		<div class="container fiv">
			<div class="row">
			    <div class="col-6 col-sm-12 col-md-6 col-lg-6">
						<h3 class="uu">Best Structure Buildings in Kodaikanal</h3>
						<h5 class="oi">How We Work</h5>
						<h6 class="ty">At Bright Interiors, we follow a streamlined process to ensure your vision is brought to life with precision, creativity, and care.</h6>
						<h5 class="fi">Consultation</h5>
						<h6 class="ty">We understand your needs and preferences to create a personalized plan.</h6><hr>
						<h5 class="wa">Design & Planning</h5>
						<h6 class="ty">Our team designs and plans the space with detailed attention to functionality.</h6><hr>
						<h5 class="np">Execution & Delivery</h5>
						<h6 class="ty">We execute with professionalism, delivering your project on time and within budget.</h6>
                    </div> 
					<div class="col-6 col-sm-12 col-md-6 col-lg-6">
						<img src="images/you.jpg" width="510px" height="450px">
					</div>
				</div>
			</div>  

        <section class="hero-selction">
        	<div class="hero-overlay">
        	<div class="container hero-text">
        	   <h1 class="black">Transforming ideas into spaces that reflect your unique style and needs</h1>
        	    
        	 </div><center> <a href="contact.php" class="btn btn-warning rounded-pill" style="background-color:#f7931e; text-decoration:none;">Contact Now<i class="bi bi-arrow-right ms-2"></i></a></center>
        	</div>
        	</section>



       <!--  <div class="container mt-3">
        	<div class="row">
        		<div class="col-2 col-sm-12 col-md-6 col-lg-6">
        			<img src="images/images/choose.jpg" class="blue">
        		</div>
        		<div class="col-2 col-sm-12 col-md-6 col-lg-6">
        			<h6 class="mm">Why Choose Us?</h6>
        			<h6 class="qq">We deliver quality designs, exceptional service, and cost-effective solutions, ensuring your vision is realized.</h6>
        		</div>
        	</div>
        </div>
 -->        




        <h6 class="text-center ii">Gallery</h6>
        <h2 class="text-center ni">Best Structure Buildings</h2>

        <div class="container">
        	<div class="row g-4">
        		<div class="col-4 col-sm-12 col-md-6 col-lg-4">
        		<img width="100%" src="images/images/pic1.jpg">
        		</div>
        		<div class="col-4 col-sm-12 col-md-6 col-lg-4">
        		<img width="100%" src="images/images/pic2.jpg">
        		</div>
        		<div class="col-4 col-sm-12 col-md-6 col-lg-4">
        		<img width="100%" src="images/images/pic3.jpg">
        		</div>
        		<div class="col-4 col-sm-12 col-md-6 col-lg-4">
        		<img width="100%" src="images/images/pic4.jpg">
        		</div>
        		<div class="col-4 col-sm-12 col-md-6 col-lg-4">
        		<img width="100%" src="images/images/pic5.jpg">
        		</div>
        		<div class="col-4 col-sm-12 col-md-6 col-lg-4">
        		<img width="100%" src="images/images/pic6.jpg">
        		</div>
        	</div>
        </div>

        <center><a href="https://brightinteriors.in/best-construction-company-in-coimbatore.php" class="you">View more</a></center>

        <div class="container">
        	<div class="row">
        		<div class="col-2 col-sm-12 col-md-6 col-lg-6">
        			<img src="images/images/testi.jpg">
        		</div>
        		<div class="col-2 col-sm-12 col-md-6 col-lg-6">
        			<h6 class="sd pb-4">Testimonials</h6>
        			<ul class="d-flex tgg">
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        				<li class="fa solid fa-star"></li>
        			</ul>
        			<h6 class="opp">We hired Bright Interiors to redesign our living room, and they delivered a beautiful, well-thought-out space. The team was efficient and really understood our vision.</h6>
        			<div class="d-flex">
        				<div>
        					<img src="images/images/alu.jpg" height="60px" width="60px">
        				</div>
        				<div class="ee"><h5>Venkatesan</h5></div>
        			</div>
             </div>
        		</div>
        	</div>
        </div>
      <center><h6 class="jk">Latest Updates</h6></center>

      <div class="container">
      	<div class="row g-4">
      		<div class="col-12 col-sm-12 col-md-6 col-lg-4 tube text-center">
      			<img src="images/images/last1.jpg" height="300px" width="300px">
      			<div class="mt-2 lo">
      			<span class="icon"><i class="fa fa-user"></i></span>
      			<span class="text">Bright interiors</span>
      		</div>
      		<h4 class="hoo">Kerala Roofing:Traditional Elegance With a Natural And Timeless Appeal</h4>
      		</div>
      		<div class="col-12 col-sm-12 col-md-6 col-lg-4 tube text-center">
      			<img src="images/images/last2.jpg" height="300px" width="300px">
      			<div class="mt-2 lo">
      			<span class="icon"><i class="fa fa-user"></i></span>
      			<span class="text">Bright interiors</span>
      			</div>
      			<h4 class="hoo">Shuttle Courts:Expertly Design For Private And Club-Level Sports Spaces</h4>
      		</div>
      		<div class="col-12 col-sm-12 col-md-6 col-lg-4 tube text-center">
      			<img src="images/images/last3.jpg" height="300px" width="300px">
      			<div class="mt-2 lo">
      			<span class="icon"><i class="fa fa-user"></i></span>
      			<span class="text">Bright interiors</span>
      			<h4 class="hoo">Drouble Roofing Solutions With 10-Year Color Warranty for  All Spaces</h4>
      			</div>
      		</div>
      		</div>
      </div>

      <?php include"footer.php";?>
</body>
</html>