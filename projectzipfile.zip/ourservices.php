

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cube Men Construction company</title>
	<link rel="icon" type="img/png" href="logo1.jpg">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>




    <style>










		a{
   text-decoration: none;
   color: black;
}
.top{
	list-style-type: none ;
	display: flex; gap: 100px; padding: 0;
   
}

.top a{
   text-decoration: none;
   color: black;
}

a:hover{
	color: orange;
}
.parent{
	display: flex;
	justify-content: space-between; 
}
.posit {
    position: relative;
    top: -78px;
    z-index: -20;
}







    	.janu{
    background: gray!important;
}
.making{
    background:orange!important;
}
.mani{
background: var(--white-color);
    padding: 30px;
    border: 1px solid var(--divider-color);
    border-radius: 40px;
    height: calc(100% - 30px);
    margin-bottom: 30px;
    position: relative;
    z-index: 1;
}
.m{
    background: var(--white-color);
    padding: 30px;
    border: 1px solid var(--divider-color);
    border-radius: 40px;
    height: calc(100% - 30px);
    margin-bottom: 30px;
    position: relative;
    z-index: 1;

}
.zz{
    border: 2px;
}
.mmm{
    border: 2px solid   gray;
}
.gyy::before{
    content: "\f14a";
    font-family: "fontAwesome";
    font-color:orange;
}  

.ami{
    font-size: 24px;

}
.jaya{
    line-height: 1.7em;
    text-align: justify;
    font-size: 17px;
    font-weight: 400;
}
.section-title{
    font-weight: 700;
    line-height: 1.1em;
    color: #d15901;
    font-size: 32px;
    margin-bottom: 0px;
}
.bi bi-check-circle-fil gyy ul li::before {
    content: '\f058';
    position: absolute;
    font-family: var(--icon-font);    
    font-size: 20px;
    font-weight: 900;
    line-height: normal;
    color: #d15901;
}
.Ab{

.section-title h3 {
    display: inline-block;
    position: relative;
    font-size: 16px;
    font-weight: 500;
    line-height: 1.6em;
    text-transform: capitalize;
    color: var(--accent-color);
    padding-left: 35px;
    margin-bottom: 20px;
}

.devii{
    font-weight: 700;
    line-height: 1.1em;
    color: orange;
    font-size: 32px;
    margin-bottom: 0px;
}
.bi-check-circle-fill{
    color: oranges;
}
.bc{
    margin-top: 40px;
}
.cards{
    color: orange;
    font-size: 60px;
}
.kana::before{
    font-weight: 10px;

}
.bar{
    padding-right: 2px;
}
.lo{
   color: #d15901;
}
.ho{
   color: black;
    font-family: var(--title-font);
    font-size: 22px;
    font-style: normal;
    font-weight: 700;
    line-height: 32px;
    overflow: hidden;
 }
 .tube{
    position: relative;
    padding: 24px;
    max-width: 400px;
    border-radius: 16px;
    border: 1px solid #E5E5E5;
    background-color: #fff;
    -webkit-border-radius: 16px;
 }



    </style>
</head>
<body>


	<?php include"header.php"?>

<div class="oviya posit">
	<h1 class="text-center ayisha">Our Services</h1>
</div>
	
	<div class="container">
		<div class="row">
		
			<div class="col-lg-6	col-12">

				<h1 style="color:orange;">Structure Buildings</h1>
				<p>Experience cost-effective and time-efficient construction with our Structure Buildings solutions. Designed to be 30% more affordable than conventional methods, our approach ensures high quality while reducing costs significantly. We guarantee project completion within just 3 months, making us the perfect choice for those seeking quick turnarounds without compromising on durability or design.</p><br>
				<p>Our structures are versatile, sustainable, and adaptable to various needs, including homes, offices, and commercial spaces. Trust us to deliver innovative, long-lasting solutions tailored to your vision and requirements.</p>
				<a href="about.php" style="display: inline-block; margin-bottom;30px;">contactus</a>                                                                                                                            
				</div>
				<br>
			
			<div class="col-lg-6	col-12">
				<img src="ser.jpg"width="100%">
			</div>                                                   
		

	</div>
</div>




	<div	style="background-color: gray;padding-bottom: 40px;">
	<div	class="container d-flex">
		<div	class="row	g-5">                             
			<h2	class="text-light	text-center">Structure Buildings in Dindigul</h2>
		
			<div	class="col-12	col-md-6	col-lg-4	text-center">
				                                                                   
				<div style="background-color: white;padding: 15px;border-radius: 15px;">
					<div class="section-container">
					<div class="cards">
						<div style="font-size: 38px; color: orange;">
							<i class="fa-solid fa-hand-holding-usd"></i>
						</div>
						
					
					<h1	class="ami">Cost-Effective Solutions</h1>                                            
				<p	class="jaya">Save 30% on costs compared to conventional construction. Our innovative methods ensure affordability without compromising on quality or durability.</p>
				</div>
				

			</div>
		</div>
	</div>
				<div	class="col-12	col-md-6	col-lg-4	text-center	">
				<div	style="background-color: white;padding-bottom: 100px;border-radius: 10px;
				padding: 35px;">
					<div class="cards">
						<div style="font-size:38px;color: orange;">
							<i class="fa-solid fa-truck-fast"></i>
						</div>
						
					
						<h1	class="ami">fastprojectdelivery</h1>                                             
				<p	class="jaya">Get your structure completed within just 3 months! We prioritize efficiency to deliver projects on time, every time.</p>
					
				
			</div>
		</div>
			

			
		</div>
			<div	class="col-12	col-md-4	col-lg-4	text-center">
				<div	style="background-color: white;padding: 15px;border-radius:10px;">
					<div class="cards">
						<div style="font-size:38px;color:orange;">
							<i class="fa-solid fa-pen-to-square"></i>
						</div>
						
					<h1	class="ami">Sustainable & Flexible Designs</h1>
				<p	class="jaya">Our designs are versatile, sustainable, and tailored to your needs, ensuring long-lasting, functional structures for homes, offices, and other spaces.</p>
			

					
				</div>
				
			</div>
</div>
</div>
</div>
</div>

	<div class="container">
		<div class="row"	style="margin-top: 50px;">
			<div class="col-12	col-lg-6">
				<img src="Service6.jpg"	width="100%"	style="margin-top:50px;">
			</div>
			<div class="col-12	col-lg-6">
				<h3	class="section-title">Why Choose Us for Structure Buildings?</h3> 
				<p>Experience unmatched construction solutions designed to save you time and money without compromising quality.
				 Our innovative approach ensures exceptional results tailored to your needs.</p><br>
			
					<div class="d-flex">
					<div style="color:orange; margin-right:10px";>
        <i class="bi bi-check-circle-fill	gyy"></i>
      </div>
      <div>
        <h6><strong>Budget-Friendly:</strong> Enjoy 30% cost savings compared to traditional methods
      </h6>
      </div>
    </div>
    <div class="d-flex">
    	<div style="color: orange;margin-right: 10px;">
    	       <i class="bi bi-clock-fill	gyy"></i>
    	     </div>
    	     <div>
       <strong>Timely Completion:</strong> Guaranteed project delivery within 3 months.
     </div>
   </div>

       <div class="d-flex">
       	<div style="color: orange;margin-right: 10px;"> 
       		<i class="bi bi-check2-square	gyy"></i>
       	</div>
       		<div>
       		   <strong>Sustainable Designs:</strong> Durable, adaptable, and environmentally conscious structures.
       		</div>
      
			</div> 
		</div>
	</div> 
	<section class="spacer-bottom class bc">
    <div class="section-title pb-3">
        <h3 class="sm-title clr-main text-center mb-2 d-block p-0">Structure Buildings in Saibaba Colony</h3>
    



	 <!--  <div class="container">
    <h2 style="color:black;">Our Other Services</h2>
    <div class="row">
      <div	class="col-md-4	lg-4">
           		<img src="serlast2.jpg"width=353.33px	class="card-img-top"alt="keralatype-roofing">
   
      		</div>
      		 <div	class="col-md-4	lg-4">
           		<img src="roofing1.png"width=353.33px	class="card-img-top"alt=roofing1">
   
      		</div>                         
      		 <div	class="col-md-4	lg-4">                                                       
      		 <img src="interiors.php "width=353.33"> --> 
      		       <div class="container">
      	<div class="row g-4">
      		<div class="col-12 col-sm-12 col-md-6 col-lg-4 tube text-center">
      			<img src="images/images/last1.jpg" height="300px" width="300px">
      			
      		<h4 class="ho">Kerala Roofing</h4>
      		</div>
      		<div class="col-12 col-sm-12 col-md-6 col-lg-4 tube text-center">
      			<img src="super3.jpg" height="300px" width="300px">
      			
      			<h4 class="ho">Warehouse</h4>
      		</div>
      		<div class="col-12 col-sm-12 col-md-6 col-lg-4 tube text-center">
      			<img src="serlast1.jpg" height="300px" width="300px">
      			<div>
      			<h4 class="ho">Structural Office & Houses</h4>
      			</div>
      		</div>
      		</div>
      </div>                            
      		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            s
                                   
      		</div>                                                                                                                                                                                                         
      	</div>
      </div>
      
      <?php include"footer.php"?>

	
 

</body>
</html>
                                                                      