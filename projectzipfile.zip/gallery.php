<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Cube Men Construction company</title>
	<link rel="icon" type="img/png" href="logo1.jpg">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
  	
		{
   text-decoration: none;
   color: black;
}
.top{
	list-style-type: none ;
	display: flex; gap: 100px; padding: 0;
   
}

.top a{
   text-decoration: none;
   color: black;
}

a:hover{
	color: orange;
}
.parent{
	display: flex;
	justify-content: space-between; 
}
.posit {
    position: relative;
    top: -78px;
    z-index: -20;
}
.gala{
	border: 2px solid gray;
	margin-top: 37px;
	padding: 20px 30px 30px 30px;
}


  </style>

</head>
<body>

	<?php include"header.php"?>

	<div class="oviya posit">
	<h1 class="text-center ayisha">Gallery</h1>
</div>


<div>
	<h1 class="text-center">Gallery</h1>
</div>


<section>
	<div class="container">
		<h1 class="main-heading">Best Construction Company in dindigul</h1>
		<div class="row g-4 gala">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="Building2.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="Building1.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="Building3.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="gal4.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="gal5.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="gal6.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="gal7.jpg"> 	
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="gal8.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="gal9.jpg">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="images/gallery2.png">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="images/gallery3.png">
			<img class="col-lg-3 col-md-4 col-sm-6 col-12 " src="images/gallery4.png">
		</div>
	</div>
</section>




<!-- <script src="script.js">

</script> -->


<?php include"footer.php"?>

</body>
</html>






 